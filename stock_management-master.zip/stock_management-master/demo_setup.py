#!/usr/bin/env python
"""
Demo setup script using SQLite for the Smart Inventory Management System
"""
import os
import sys
import django
from django.core.management import execute_from_command_line

def setup_demo():
    """Setup the demo database with SQLite"""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'inventory_system.settings_sqlite')
    django.setup()
    
    print("Setting up Smart Inventory Management System Demo...")
    print("Using SQLite database for demonstration")
    print("=" * 60)
    
    # Make migrations
    print("1. Creating database migrations...")
    execute_from_command_line(['manage.py', 'makemigrations', '--settings=inventory_system.settings_sqlite'])
    
    # Apply migrations
    print("2. Applying database migrations...")
    execute_from_command_line(['manage.py', 'migrate', '--settings=inventory_system.settings_sqlite'])
    
    # Create sample data
    print("3. Creating sample data...")
    execute_from_command_line(['manage.py', 'create_sample_data', '--settings=inventory_system.settings_sqlite'])
    
    print("=" * 60)
    print("🎉 Demo setup completed successfully!")
    print("\nTo run the demo server:")
    print("python manage.py runserver --settings=inventory_system.settings_sqlite")
    print("\nLogin credentials:")
    print("Staff User - Username: staff, Password: staff123")
    print("Admin User - Username: admin, Password: admin123")
    print("\nAccess the application at: http://127.0.0.1:8000/")

if __name__ == '__main__':
    setup_demo()