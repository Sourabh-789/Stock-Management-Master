#!/usr/bin/env python
"""
Test database connection script
"""
import os
import sys
import django
from django.conf import settings

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'inventory_system.settings')
django.setup()

from django.db import connection
from django.core.management import execute_from_command_line

def test_connection():
    try:
        # Test database connection
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
            print("✅ Database connection successful!")
            print(f"Test query result: {result}")
            
        # Check if database exists
        cursor.execute("SHOW DATABASES LIKE 'inventory_db'")
        db_exists = cursor.fetchone()
        if db_exists:
            print("✅ Database 'inventory_db' exists")
        else:
            print("❌ Database 'inventory_db' does not exist")
            print("Creating database...")
            cursor.execute("CREATE DATABASE inventory_db")
            print("✅ Database 'inventory_db' created")
            
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        print("\nTroubleshooting steps:")
        print("1. Make sure MySQL server is running")
        print("2. Check if the password in .env file is correct")
        print("3. Try connecting to MySQL manually:")
        print("   mysql -u root -p")
        return False
    
    return True

if __name__ == '__main__':
    print("Testing database connection...")
    print("=" * 40)
    
    # Print current settings
    print(f"Database Name: {settings.DATABASES['default']['NAME']}")
    print(f"Database User: {settings.DATABASES['default']['USER']}")
    print(f"Database Host: {settings.DATABASES['default']['HOST']}")
    print(f"Database Port: {settings.DATABASES['default']['PORT']}")
    print("=" * 40)
    
    if test_connection():
        print("\n🎉 Database connection test passed!")
    else:
        print("\n💥 Database connection test failed!")
        sys.exit(1)