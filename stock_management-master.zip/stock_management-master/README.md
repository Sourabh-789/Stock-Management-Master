# Smart Inventory Management System - Staff Portal

A comprehensive Django-based inventory management system designed for staff users to manage products, orders, and generate reports.

## Features

### Staff Portal Features
- **Products Management**: View all products with search and filter capabilities
- **Order Management**: Create, approve, and reject orders with automatic stock updates
- **Reports**: View order history and stock movement reports with date filtering
- **Alerts**: Real-time alerts for low stock and out-of-stock products
- **Role-based Access**: Staff-only access with Django authentication

### Key Functionalities
- ✅ Staff authentication with `is_staff=True` requirement
- ✅ Product catalog with stock status indicators
- ✅ Order creation with product selection and quantity management
- ✅ Order approval/rejection workflow with stock updates
- ✅ Automatic stock transaction recording
- ✅ Low stock and out-of-stock alerts
- ✅ Comprehensive reporting with date filters
- ✅ Responsive Bootstrap UI
- ✅ Real-time stock status updates

## Technology Stack

- **Backend**: Django 4.2.7
- **Database**: MySQL
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Authentication**: Django built-in authentication
- **UI Framework**: Bootstrap 5 with Font Awesome icons

## Installation & Setup

### Prerequisites
- Python 3.8+
- MySQL Server
- pip (Python package manager)

### 1. Clone the Repository
```bash
git clone <repository-url>
cd inventory_system
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Environment Configuration
1. Copy the environment template:
```bash
cp .env.example .env
```

2. Edit the `.env` file and update your MySQL password:
```bash
# Database Configuration
DB_NAME=inventory_db
DB_USER=root
DB_PASSWORD=your_actual_mysql_password
DB_HOST=localhost
DB_PORT=3306
```

### 4. Database Setup
1. Create a MySQL database named `inventory_db`
2. Update database credentials in `inventory_system/settings.py`:
```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'inventory_db',
        'USER': 'your_mysql_username',
        'PASSWORD': 'your_mysql_password',
        'HOST': 'localhost',
        'PORT': '3306',
    }
}
```

### 5. Run Migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### 6. Create Sample Data
```bash
python manage.py create_sample_data
```

This command will create:
- Sample products across different categories
- Staff and admin users
- Sample orders with different statuses
- Stock transactions

### 6. Run the Development Server
```bash
python manage.py runserver
```

Visit `http://127.0.0.1:8000/` to access the application.

## Default Login Credentials

After running the `create_sample_data` command:

**Staff User:**
- Username: `staff`
- Password: `staff123`

**Admin User:**
- Username: `admin`
- Password: `admin123`

## Application Structure

### Models
- **Product**: Stores product information, stock levels, and reorder points
- **Order**: Manages order information and status
- **OrderItem**: Links products to orders with quantities
- **StockTransaction**: Records all stock movements for audit trail

### Views & URLs
- `/` - Dashboard with overview statistics
- `/products/` - Product listing with search and filters
- `/orders/` - Order management interface
- `/orders/create/` - Create new orders
- `/orders/<id>/` - Order details and approval/rejection
- `/reports/` - Order history and stock movement reports
- `/alerts/` - Low stock and out-of-stock alerts

### Key Features Implementation

#### 1. Staff Authentication
- All views protected with `@login_required` and `@user_passes_test(is_staff_user)`
- Custom staff check function ensures only staff users can access

#### 2. Order Management Workflow
- **Create**: Staff can create orders by selecting products and quantities
- **Approve**: Approving an order automatically updates stock and creates transactions
- **Reject**: Orders can be rejected with mandatory reason

#### 3. Stock Management
- Real-time stock status calculation (In Stock/Low Stock/Out of Stock)
- Automatic stock updates on order approval
- Stock transaction logging for audit trail

#### 4. Alerts System
- Automatic detection of low stock products (quantity ≤ reorder_level)
- Out-of-stock product identification
- Visual alerts with color coding

#### 5. Reporting
- Order history with status filtering
- Stock movement tracking
- Date-range filtering for reports

## Database Schema

### Product Table
- `id` (Primary Key)
- `name` (Product name)
- `category` (Product category)
- `quantity` (Current stock)
- `reorder_level` (Minimum stock threshold)
- `price` (Unit price)
- `description` (Product description)
- `created_at`, `updated_at` (Timestamps)

### Order Table
- `id` (Primary Key)
- `order_number` (Auto-generated unique identifier)
- `created_by` (Foreign Key to User)
- `status` (pending/approved/rejected)
- `total_amount` (Calculated total)
- `notes` (Optional order notes)
- `rejection_reason` (Required for rejected orders)
- `approved_by` (Foreign Key to User)
- `created_at`, `updated_at` (Timestamps)

### OrderItem Table
- `id` (Primary Key)
- `order` (Foreign Key to Order)
- `product` (Foreign Key to Product)
- `quantity` (Ordered quantity)
- `unit_price` (Price at time of order)

### StockTransaction Table
- `id` (Primary Key)
- `product` (Foreign Key to Product)
- `transaction_type` (in/out/adjustment)
- `quantity` (Transaction quantity)
- `reference_order` (Optional Foreign Key to Order)
- `reason` (Transaction reason)
- `created_by` (Foreign Key to User)
- `created_at` (Timestamp)

## Security Features

- CSRF protection on all forms
- Staff-only access control
- SQL injection prevention through Django ORM
- XSS protection through template escaping
- Secure password handling

## UI/UX Features

- Responsive Bootstrap design
- Intuitive navigation with active page indicators
- Color-coded stock status indicators
- Real-time form validation
- Confirmation dialogs for critical actions
- Auto-refresh for alerts page
- Pagination for large datasets
- Search and filter capabilities

## Future Enhancements

- Export functionality for reports (CSV/PDF)
- Email notifications for low stock alerts
- Barcode scanning integration
- Advanced analytics and charts
- Multi-location inventory support
- Supplier management
- Purchase order generation

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Verify MySQL server is running
   - Check database credentials in settings.py
   - Ensure database `inventory_db` exists

2. **Migration Errors**
   - Delete migration files and run `makemigrations` again
   - Check for model conflicts

3. **Permission Denied**
   - Ensure user has `is_staff=True` set
   - Check login credentials

4. **Static Files Not Loading**
   - Run `python manage.py collectstatic` in production
   - Check STATIC_URL and STATICFILES_DIRS settings

## Support

For issues and questions, please check the troubleshooting section or create an issue in the repository.

## License

This project is for educational and demonstration purposes.