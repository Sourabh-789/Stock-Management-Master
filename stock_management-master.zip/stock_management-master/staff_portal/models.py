"""
Models for the Staff Portal Inventory Management System
"""
from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


class Product(models.Model):
    """Product model to store inventory items"""
    name = models.CharField(max_length=200)
    category = models.CharField(max_length=100)
    quantity = models.IntegerField(default=0)
    reserved_quantity = models.IntegerField(default=0)
    reorder_level = models.IntegerField(default=10)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    @property
    def stock_status(self):
        """Return stock status based on quantity"""
        if self.quantity == 0:
            return 'Out of Stock'
        elif self.quantity <= self.reorder_level:
            return 'Low Stock'
        else:
            return 'In Stock'

    @property
    def is_low_stock(self):
        """Check if product is low on stock"""
        return self.quantity <= self.reorder_level

    @property
    def is_out_of_stock(self):
        """Check if product is out of stock"""
        return self.quantity == 0

    @property
    def available_quantity(self):
        """Calculate available stock (Actual - Reserved)"""
        return self.quantity - self.reserved_quantity

    class Meta:
        ordering = ['name']


class Order(models.Model):
    """Order model to manage inventory orders"""
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('pending_payment', 'Pending Payment'),
        ('paid', 'Paid'),
        ('confirmed', 'Confirmed'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]

    order_number = models.CharField(max_length=20, unique=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_orders')
    customer_name = models.CharField(max_length=100, default='Walk-in Customer')
    customer_contact = models.CharField(max_length=100, blank=True, help_text="Customer Mobile Number")
    customer_email = models.EmailField(max_length=254, blank=True, null=True, help_text="Customer Email Address")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    payment_method = models.CharField(max_length=50, blank=True, null=True)
    razorpay_order_id = models.CharField(max_length=100, blank=True, null=True)
    razorpay_payment_id = models.CharField(max_length=100, blank=True, null=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    notes = models.TextField(blank=True)
    rejection_reason = models.TextField(blank=True)
    approved_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_orders')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Order {self.order_number}"

    def save(self, *args, **kwargs):
        if not self.order_number:
            # Generate order number
            last_order = Order.objects.order_by('-id').first()
            if last_order:
                last_number = int(last_order.order_number.split('-')[1])
                self.order_number = f"ORD-{last_number + 1:06d}"
            else:
                self.order_number = "ORD-000001"
        super().save(*args, **kwargs)

    def calculate_total(self):
        """Calculate total amount for the order"""
        total = sum(item.subtotal for item in self.items.all())
        self.total_amount = total
        self.save()
        return total

    class Meta:
        ordering = ['-created_at']


class OrderItem(models.Model):
    """Order items to store products in each order"""
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.product.name} x {self.quantity}"

    @property
    def subtotal(self):
        """Calculate subtotal for this order item"""
        return self.quantity * self.unit_price

    def save(self, *args, **kwargs):
        if not self.unit_price:
            self.unit_price = self.product.price
        super().save(*args, **kwargs)

    class Meta:
        unique_together = ['order', 'product']


class StockTransaction(models.Model):
    """Track all stock movements"""
    TRANSACTION_TYPES = [
        ('in', 'Stock In'),
        ('out', 'Stock Out'),
        ('adjustment', 'Adjustment'),
    ]

    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='transactions')
    transaction_type = models.CharField(max_length=20, choices=TRANSACTION_TYPES)
    quantity = models.IntegerField()
    reference_order = models.ForeignKey(Order, on_delete=models.SET_NULL, null=True, blank=True)
    reason = models.CharField(max_length=200)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.product.name} - {self.transaction_type} - {self.quantity}"

    class Meta:
        ordering = ['-created_at']


class RestockRequest(models.Model):
    """Model to track staff requests for out-of-stock items"""
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'), # Ordered
        ('rejected', 'Rejected'),
        ('fulfilled', 'Fulfilled'), # Received
    ]

    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='restock_requests')
    requested_quantity = models.IntegerField()
    reason = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    
    # B2B Fields
    dealer_name = models.CharField(max_length=100, blank=True, null=True)
    cost_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    
    related_order = models.ForeignKey(Order, on_delete=models.SET_NULL, null=True, blank=True, related_name='restock_requests')
    
    requested_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_requests')
    processed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='processed_requests')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Restock Request: {self.product.name} ({self.requested_quantity})"

    @property
    def total_cost(self):
        """Calculate total amount for the restock request (for B2B bills)"""
        # NOTE: cost_price here acts as a UNIT price or TOTAL price?
        # The user's prompt in Alerts modal said "Estimated Cost / Amount" for "Total amount".
        # So `cost_price` IS the total amount.
        # But if the user wants "cost of EACH item" and "Total cost", I should clarify.
        # However, in Alerts HTML I added placeholder="Total amount for admin to pay".
        # So let's assume `cost_price` is the TOTAL amount for simplicity unless the schema changes.
        # Wait, the user said "cost of each item and total cost of each item". This implies unit_price * quantity.
        # But my current model only has `cost_price`.
        # I will treat `cost_price` as the TOTAL amount for now to match the "Bill Details" display I created.
        if self.cost_price:
            return self.cost_price
        return 0

    class Meta:
        ordering = ['-created_at']


class Notification(models.Model):
    """System notifications for staff/admin"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Notification for {self.user.username}: {self.message[:20]}..."
        
    class Meta:
        ordering = ['-created_at']