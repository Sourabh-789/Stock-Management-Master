from django.core.mail import send_mail, EmailMultiAlternatives
from django.conf import settings
from django.utils.html import strip_tags
from urllib.parse import quote
from twilio.rest import Client
import logging
import os

logger = logging.getLogger(__name__)

def send_order_notification(order, link):
    """
    Send detailed notification to customer via Email and SMS.
    """
    subject = f"Order #{order.order_number} Payment Request"
    
    # 1. Build Product Details String
    products_text = ""
    products_html_rows = ""
    for item in order.items.all():
        products_text += f"- {item.product.name}: {item.quantity} x Rs.{item.unit_price} = Rs.{item.subtotal}\n"
        products_html_rows += f"<tr><td style='padding:5px; border-bottom:1px solid #ddd;'>{item.product.name}</td><td style='padding:5px; border-bottom:1px solid #ddd;'>{item.quantity}</td><td style='padding:5px; border-bottom:1px solid #ddd;'>Rs.{item.subtotal}</td></tr>"

    # 2. Generate QR Code URL
    qr_url = f"https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={quote(link)}"

    # 3. Text Message
    text_message = f"""
    Dear {order.customer_name},

    Your order has been placed successfully.

    Order Details:
    ----------------
    Order ID: {order.order_number}
    
    Items:
    {products_text}
    
    Total Amount: Rs.{order.total_amount}

    Payment Link:
    {link}

    This is an automated message.
    """

    # 4. HTML Message with QR
    html_message = f"""
    <h2>Order #{order.order_number} Details</h2>
    <p>Dear {order.customer_name},</p>
    <p>Your order has been placed successfully.</p>
    
    <table style="width:100%; max-width:500px; border-collapse:collapse; margin-bottom:20px;">
        <tr style="background:#f8f9fa; text-align:left;">
            <th style="padding:8px;">Product</th>
            <th style="padding:8px;">Qty</th>
            <th style="padding:8px;">Total</th>
        </tr>
        {products_html_rows}
        <tr>
            <td colspan="2" style="padding:8px; font-weight:bold; text-align:right;">Grand Total:</td>
            <td style="padding:8px; font-weight:bold;">Rs.{order.total_amount}</td>
        </tr>
    </table>

    <div style="text-align:center; padding:20px; background:#f1f5f9; border-radius:10px; display:inline-block;">
        <p style="margin-top:0; font-weight:bold;">Scan to Pay</p>
        <img src="{qr_url}" alt="Payment QR Code" style="width:150px; height:150px;" />
        <p style="margin-bottom:0;"><a href="{link}" style="color:#2563eb;">Or click here to pay</a></p>
    </div>
    """

    recipient = order.customer_contact
    
    # Send Email
    if order.customer_email:
        try:
            msg = EmailMultiAlternatives(
                subject=subject,
                body=text_message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[order.customer_email]
            )
            msg.attach_alternative(html_message, "text/html")
            msg.send(fail_silently=False)
            
            print(f"EMAIL SENT TO {order.customer_email}")
        except Exception as e:
            logger.error(f"Failed to send email: {e}")
            print(f"EMAIL FAILED: {e}")

    # Send SMS (Real logic)
    if order.customer_contact:
        send_sms(order.customer_contact, f"Hello {order.customer_name}, your order {order.order_number} is placed. Total: Rs.{order.total_amount}. Pay here: {link}")

def send_sms(mobile, message):
    """
    Send REAL SMS using Twilio.
    """
    account_sid = getattr(settings, 'TWILIO_ACCOUNT_SID', None)
    auth_token = getattr(settings, 'TWILIO_AUTH_TOKEN', None)
    from_number = getattr(settings, 'TWILIO_PHONE_NUMBER', None)

    if not (account_sid and auth_token and from_number):
        print("--------------------------------------------------")
        print("TWILIO CREDENTIALS MISSING. SMS NOT SENT.")
        print("Run 'python setup_wizard.py' to configure them.")
        print(f"TARGET: {mobile}")
        print(f"MESSAGE: {message}")
        print("--------------------------------------------------")
        return

    try:
        client = Client(account_sid, auth_token)
        message = client.messages.create(
            body=message,
            from_=from_number,
            to=mobile
        )
        print(f"SMS SENT TO {mobile} (SID: {message.sid})")
    except Exception as e:
        print(f"SMS FAILED: {e}")
        logger.error(f"Failed to send SMS: {e}")

def send_payment_receipt(order):
    """
    Send payment receipt confirmation to customer via Email and SMS.
    """
    subject = f"Payment Receipt - Order #{order.order_number}"
    
    # Format date
    payment_date = order.updated_at.strftime('%d-%m-%Y %H:%M')
    
    message = f"""
    Dear {order.customer_name},

    Payment Received Successfully!

    Receipt Details:
    ----------------
    Order ID: {order.order_number}
    Amount Paid: ₹{order.total_amount}
    Transaction ID: {order.razorpay_payment_id}
    Date: {payment_date}

    Thank you for your business!
    """
    
    
    # Send Email
    if order.customer_email:
        try:
            send_mail(
                subject=subject,
                message=message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[order.customer_email],
                fail_silently=False,
            )
            print(f"RECEIPT EMAIL SENT TO {order.customer_email}")
        except Exception as e:
            logger.error(f"Failed to send receipt email: {e}")

    # Send SMS
    if order.customer_contact:
        sms_body = f"Payment successful for order {order.order_number}. Total: Rs.{order.total_amount}. Txn: {order.razorpay_payment_id}"
        send_sms(order.customer_contact, sms_body)
