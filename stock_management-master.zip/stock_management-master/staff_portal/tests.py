"""
Tests for the Staff Portal Inventory Management System
"""
from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from decimal import Decimal
from .models import Product, Order, OrderItem, StockTransaction


class ProductModelTest(TestCase):
    """Test Product model functionality"""
    
    def setUp(self):
        self.product = Product.objects.create(
            name='Test Product',
            category='Test Category',
            quantity=15,
            reorder_level=10,
            price=Decimal('99.99'),
            description='Test product description'
        )
    
    def test_product_creation(self):
        """Test product is created correctly"""
        self.assertEqual(self.product.name, 'Test Product')
        self.assertEqual(self.product.quantity, 15)
        self.assertEqual(self.product.price, Decimal('99.99'))
    
    def test_stock_status_in_stock(self):
        """Test stock status when product is in stock"""
        self.assertEqual(self.product.stock_status, 'In Stock')
    
    def test_stock_status_low_stock(self):
        """Test stock status when product is low on stock"""
        self.product.quantity = 5
        self.product.save()
        self.assertEqual(self.product.stock_status, 'Low Stock')
    
    def test_stock_status_out_of_stock(self):
        """Test stock status when product is out of stock"""
        self.product.quantity = 0
        self.product.save()
        self.assertEqual(self.product.stock_status, 'Out of Stock')
    
    def test_is_low_stock(self):
        """Test low stock property"""
        self.product.quantity = 8
        self.product.save()
        self.assertTrue(self.product.is_low_stock)
    
    def test_is_out_of_stock(self):
        """Test out of stock property"""
        self.product.quantity = 0
        self.product.save()
        self.assertTrue(self.product.is_out_of_stock)


class OrderModelTest(TestCase):
    """Test Order model functionality"""
    
    def setUp(self):
        self.user = User.objects.create_user(
            username='testuser',
            password='testpass123',
            is_staff=True
        )
        self.product = Product.objects.create(
            name='Test Product',
            category='Test Category',
            quantity=20,
            reorder_level=10,
            price=Decimal('50.00')
        )
        self.order = Order.objects.create(
            created_by=self.user,
            notes='Test order'
        )
    
    def test_order_creation(self):
        """Test order is created correctly"""
        self.assertEqual(self.order.created_by, self.user)
        self.assertEqual(self.order.status, 'pending')
        self.assertTrue(self.order.order_number.startswith('ORD-'))
    
    def test_order_number_generation(self):
        """Test automatic order number generation"""
        order2 = Order.objects.create(created_by=self.user)
        self.assertNotEqual(self.order.order_number, order2.order_number)
    
    def test_calculate_total(self):
        """Test order total calculation"""
        OrderItem.objects.create(
            order=self.order,
            product=self.product,
            quantity=2,
            unit_price=self.product.price
        )
        total = self.order.calculate_total()
        self.assertEqual(total, Decimal('100.00'))


class OrderItemModelTest(TestCase):
    """Test OrderItem model functionality"""
    
    def setUp(self):
        self.user = User.objects.create_user(
            username='testuser',
            password='testpass123',
            is_staff=True
        )
        self.product = Product.objects.create(
            name='Test Product',
            category='Test Category',
            quantity=20,
            reorder_level=10,
            price=Decimal('25.00')
        )
        self.order = Order.objects.create(created_by=self.user)
        self.order_item = OrderItem.objects.create(
            order=self.order,
            product=self.product,
            quantity=3,
            unit_price=self.product.price
        )
    
    def test_order_item_creation(self):
        """Test order item is created correctly"""
        self.assertEqual(self.order_item.quantity, 3)
        self.assertEqual(self.order_item.unit_price, Decimal('25.00'))
    
    def test_subtotal_calculation(self):
        """Test subtotal calculation"""
        self.assertEqual(self.order_item.subtotal, Decimal('75.00'))


class StaffViewsTest(TestCase):
    """Test staff portal views"""
    
    def setUp(self):
        self.client = Client()
        self.staff_user = User.objects.create_user(
            username='staff',
            password='staffpass123',
            is_staff=True
        )
        self.regular_user = User.objects.create_user(
            username='regular',
            password='regularpass123',
            is_staff=False
        )
        self.product = Product.objects.create(
            name='Test Product',
            category='Test Category',
            quantity=15,
            reorder_level=10,
            price=Decimal('99.99')
        )
    
    def test_dashboard_requires_staff(self):
        """Test dashboard requires staff login"""
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 302)  # Redirect to login
    
    def test_dashboard_denies_regular_user(self):
        """Test dashboard denies access to regular users"""
        self.client.login(username='regular', password='regularpass123')
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 302)  # Redirect due to staff check
    
    def test_dashboard_allows_staff(self):
        """Test dashboard allows staff users"""
        self.client.login(username='staff', password='staffpass123')
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 200)
    
    def test_products_list_view(self):
        """Test products list view"""
        self.client.login(username='staff', password='staffpass123')
        response = self.client.get(reverse('products_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Product')
    
    def test_products_search(self):
        """Test products search functionality"""
        self.client.login(username='staff', password='staffpass123')
        response = self.client.get(reverse('products_list'), {'search': 'Test'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Product')
    
    def test_orders_list_view(self):
        """Test orders list view"""
        self.client.login(username='staff', password='staffpass123')
        response = self.client.get(reverse('orders_list'))
        self.assertEqual(response.status_code, 200)
    
    def test_create_order_view(self):
        """Test create order view"""
        self.client.login(username='staff', password='staffpass123')
        response = self.client.get(reverse('create_order'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Add Customer Order')
    
    def test_reports_view(self):
        """Test reports view"""
        self.client.login(username='staff', password='staffpass123')
        response = self.client.get(reverse('reports'))
        self.assertEqual(response.status_code, 200)
    
    def test_alerts_view(self):
        """Test alerts view"""
        self.client.login(username='staff', password='staffpass123')
        response = self.client.get(reverse('alerts'))
        self.assertEqual(response.status_code, 200)


class StockTransactionTest(TestCase):
    """Test stock transaction functionality"""
    
    def setUp(self):
        self.user = User.objects.create_user(
            username='testuser',
            password='testpass123',
            is_staff=True
        )
        self.product = Product.objects.create(
            name='Test Product',
            category='Test Category',
            quantity=20,
            reorder_level=10,
            price=Decimal('50.00')
        )
    
    def test_stock_transaction_creation(self):
        """Test stock transaction is created correctly"""
        transaction = StockTransaction.objects.create(
            product=self.product,
            transaction_type='out',
            quantity=5,
            reason='Test transaction',
            created_by=self.user
        )
        self.assertEqual(transaction.product, self.product)
        self.assertEqual(transaction.transaction_type, 'out')
        self.assertEqual(transaction.quantity, 5)
        self.assertEqual(transaction.created_by, self.user)