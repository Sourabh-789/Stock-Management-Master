from django.urls import path
from django.contrib.auth import views as auth_views
from . import views, admin_views

urlpatterns = [
    # Login page (ROOT)
    path(
        '',
        auth_views.LoginView.as_view(
            template_name='staff_portal/login.html'
        ),
        name='login'
    ),

    # Admin Login
    path(
        'admin-login/',
        auth_views.LoginView.as_view(
            template_name='staff_portal/admin_login.html',
            next_page='admin_dashboard'
        ),
        name='admin_login'
    ),

    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    # Dashboard (protected)
    path('staff/', views.dashboard, name='dashboard'),

    # Products
    path('products/', views.products_list, name='products_list'),

    # Orders
    path('orders/', views.orders_list, name='orders_list'),
    path('orders/create/', views.create_order, name='create_order'),
    path('orders/<int:order_id>/', views.order_detail, name='order_detail'),
    path('orders/<int:order_id>/approve/', views.approve_order, name='approve_order'),
    path('orders/<int:order_id>/reject/', views.reject_order, name='reject_order'),
    path('orders/<int:order_id>/simulate-payment/', views.simulate_payment, name='simulate_payment'),
    
    # Customer Payment (Public)
    path('payment/<str:order_number>/', views.payment_page, name='payment_page'),
    path('payment/callback/', views.payment_callback, name='payment_callback'),

    # Reports
    path('reports/', views.reports, name='reports'),

    # Alerts
    path('alerts/', views.alerts, name='alerts'),

    # AJAX
    path('api/product/<int:product_id>/', views.get_product_info, name='get_product_info'),

    # Admin Dashboard
    path('admin-dashboard/', admin_views.admin_dashboard, name='admin_dashboard'),
    path('admin-dashboard/requests/', admin_views.manage_requests, name='manage_requests'),
    path('admin-dashboard/staff/', admin_views.manage_staff, name='manage_staff'),
    
    # Restock Requests (Staff)
    path('requests/create/<int:product_id>/', views.create_restock_request, name='create_restock_request'),
]
