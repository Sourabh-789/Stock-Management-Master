from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.contrib.auth.models import User
from django.db.models import Count, Q
from .models import Product, Order, RestockRequest, Notification, StockTransaction
from .models import OrderItem # Import OrderItem explicitly just in case, though usually available via models
from django.db import transaction
from django.db.models import Sum, F

def is_admin_user(user):
    """Check if user is admin"""
    return user.is_authenticated and user.is_superuser

@login_required
@user_passes_test(is_admin_user)
def admin_dashboard(request):
    """Custom Admin Dashboard Overview"""
    context = {
        'total_staff': User.objects.filter(is_staff=True, is_superuser=False).count(),
        'pending_requests': RestockRequest.objects.filter(status='pending').count(),
        'total_products': Product.objects.count(),
        'recent_requests': RestockRequest.objects.order_by('-created_at')[:5],
        'low_stock_count': Product.objects.filter(quantity__lte=10).count(), # Assuming 10 is reorder level
        'total_inventory_value': Product.objects.aggregate(total_value=Sum(F('quantity') * F('price')))['total_value'] or 0,
        'notifications': Notification.objects.filter(user=request.user, is_read=False)[:10],
    }
    return render(request, 'staff_portal/admin_dashboard.html', context)

@login_required
@user_passes_test(is_admin_user)
def manage_requests(request):
    """View and manage restock requests"""
    requests = RestockRequest.objects.all().order_by('-created_at')
    
    if request.method == 'POST':
        request_id = request.POST.get('request_id')
        action = request.POST.get('action')
        restock_request = get_object_or_404(RestockRequest, id=request_id)
        
        if action == 'approve':
            # "Place order to dealer" step
            dealer_name = request.POST.get('dealer_name')
            cost_price = request.POST.get('cost_price')
            
            if not dealer_name or not cost_price:
                 messages.error(request, 'Dealer Name and Cost Price are required for B2B Orders.')
                 return redirect('manage_requests')

            restock_request.status = 'approved'
            restock_request.dealer_name = dealer_name
            restock_request.cost_price = cost_price
            restock_request.processed_by = request.user
            restock_request.save()
            messages.success(request, f'Order placed to dealer {dealer_name} for {restock_request.product.name}.')
            
        elif action == 'fulfill':
            # "Stock Received" step
            restock_request.status = 'fulfilled'
            restock_request.save()
            
            # Update product stock
            product = restock_request.product
            product.quantity += restock_request.requested_quantity
            product.save()
            
            # Notify Staff
            Notification.objects.create(
                user=restock_request.requested_by,
                message=f"Stock Available: {product.name} has been restocked (Ref: Request #{restock_request.id})."
            )
            
            messages.success(request, f'Stock received for {product.name}.')
            
            # Update Pending Order if linked
            if restock_request.related_order and restock_request.related_order.status == 'pending':
                order = restock_request.related_order
                
                # Check if we can fulfill the ENTIRE order now with AVAILABLE stock
                can_fulfill = True
                items_to_reserve = []
                
                for item in order.items.all():
                    # We check available_quantity because we don't want to steal reserved stock
                    if item.product.available_quantity < item.quantity:
                        can_fulfill = False
                        break
                    items_to_reserve.append(item)
                
                if can_fulfill:
                    from . import notifications # Import here to avoid circular dependency
                    from django.urls import reverse

                    # Reserve Stock for this order
                    for item in items_to_reserve:
                        item.product.reserved_quantity += item.quantity
                        item.product.save()
                        
                    # Set to Pending Payment (Customer needs to pay now)
                    order.status = 'pending_payment'
                    order.save()
                    
                    messages.info(request, f"Linked Order #{order.order_number} is now READY. Stock reserved and Customer notified for payment.")
                    
                    # Notify Customer to Pay
                    try:
                        payment_link = request.build_absolute_uri(
                            reverse('payment_page', args=[order.order_number])
                        )
                        notifications.send_order_notification(order, payment_link)
                    except Exception as e:
                        print(f"Failed to send notification: {e}")
            
        elif action == 'reject':
            restock_request.status = 'rejected'
            restock_request.processed_by = request.user
            restock_request.save()
            messages.warning(request, 'Restock request rejected.')
            
        return redirect('manage_requests')

    return render(request, 'staff_portal/manage_requests.html', {'requests': requests})

@login_required
@user_passes_test(is_admin_user)
def manage_staff(request):
    """Manage staff accounts"""
    staff_users = User.objects.filter(is_staff=True, is_superuser=False)
    
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'create':
            username = request.POST.get('username')
            email = request.POST.get('email')
            password = request.POST.get('password')
            
            if User.objects.filter(username=username).exists():
                messages.error(request, 'Username already exists.')
            else:
                User.objects.create_user(username=username, email=email, password=password, is_staff=True)
                messages.success(request, f'Staff member {username} created successfully.')
                
        elif action == 'delete':
            user_id = request.POST.get('user_id')
            user = get_object_or_404(User, id=user_id)
            user.delete()
            messages.success(request, 'Staff member deleted.')
            
        return redirect('manage_staff')
        
    return render(request, 'staff_portal/manage_staff.html', {'staff_users': staff_users})
