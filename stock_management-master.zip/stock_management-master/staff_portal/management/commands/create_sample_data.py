"""
Management command to create sample data for the inventory system
"""
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from staff_portal.models import Product, Order, OrderItem, StockTransaction
from decimal import Decimal
import random


class Command(BaseCommand):
    help = 'Create sample data for the inventory management system'

    def handle(self, *args, **options):
        self.stdout.write('Creating sample data...')
        
        # Create staff user if not exists
        if not User.objects.filter(username='staff').exists():
            staff_user = User.objects.create_user(
                username='staff',
                email='staff@example.com',
                password='staff123',
                first_name='Staff',
                last_name='User',
                is_staff=True
            )
            self.stdout.write(f'Created staff user: {staff_user.username}')
        else:
            staff_user = User.objects.get(username='staff')
            self.stdout.write('Staff user already exists')

        # Create admin user if not exists
        if not User.objects.filter(username='admin').exists():
            admin_user = User.objects.create_superuser(
                username='admin',
                email='admin@example.com',
                password='admin123',
                first_name='Admin',
                last_name='User'
            )
            self.stdout.write(f'Created admin user: {admin_user.username}')
        else:
            admin_user = User.objects.get(username='admin')
            self.stdout.write('Admin user already exists')

        # Sample products data
        products_data = [
            # Electronics
            {'name': 'Laptop Dell XPS 13', 'category': 'Electronics', 'quantity': 15, 'reorder_level': 5, 'price': 999.99, 'description': 'High-performance ultrabook'},
            {'name': 'iPhone 14 Pro', 'category': 'Electronics', 'quantity': 8, 'reorder_level': 10, 'price': 1099.99, 'description': 'Latest iPhone model'},
            {'name': 'Samsung Galaxy S23', 'category': 'Electronics', 'quantity': 12, 'reorder_level': 8, 'price': 899.99, 'description': 'Android flagship phone'},
            {'name': 'iPad Air', 'category': 'Electronics', 'quantity': 6, 'reorder_level': 5, 'price': 599.99, 'description': 'Versatile tablet'},
            {'name': 'MacBook Pro 14"', 'category': 'Electronics', 'quantity': 4, 'reorder_level': 3, 'price': 1999.99, 'description': 'Professional laptop'},
            {'name': 'AirPods Pro', 'category': 'Electronics', 'quantity': 25, 'reorder_level': 15, 'price': 249.99, 'description': 'Wireless earbuds'},
            {'name': 'Gaming Mouse', 'category': 'Electronics', 'quantity': 0, 'reorder_level': 10, 'price': 79.99, 'description': 'High-precision gaming mouse'},
            {'name': 'Mechanical Keyboard', 'category': 'Electronics', 'quantity': 18, 'reorder_level': 12, 'price': 129.99, 'description': 'RGB mechanical keyboard'},
            
            # Office Supplies
            {'name': 'Office Chair', 'category': 'Office Supplies', 'quantity': 20, 'reorder_level': 8, 'price': 299.99, 'description': 'Ergonomic office chair'},
            {'name': 'Standing Desk', 'category': 'Office Supplies', 'quantity': 5, 'reorder_level': 3, 'price': 499.99, 'description': 'Adjustable standing desk'},
            {'name': 'Monitor 27"', 'category': 'Office Supplies', 'quantity': 12, 'reorder_level': 6, 'price': 329.99, 'description': '4K monitor'},
            {'name': 'Printer HP LaserJet', 'category': 'Office Supplies', 'quantity': 3, 'reorder_level': 2, 'price': 199.99, 'description': 'Laser printer'},
            {'name': 'Paper A4 (500 sheets)', 'category': 'Office Supplies', 'quantity': 50, 'reorder_level': 20, 'price': 9.99, 'description': 'Premium copy paper'},
            {'name': 'Pen Set', 'category': 'Office Supplies', 'quantity': 0, 'reorder_level': 25, 'price': 12.99, 'description': 'Ballpoint pen set'},
            {'name': 'Notebook', 'category': 'Office Supplies', 'quantity': 35, 'reorder_level': 20, 'price': 5.99, 'description': 'Spiral notebook'},
            
            # Furniture
            {'name': 'Conference Table', 'category': 'Furniture', 'quantity': 2, 'reorder_level': 1, 'price': 899.99, 'description': 'Large conference table'},
            {'name': 'Filing Cabinet', 'category': 'Furniture', 'quantity': 8, 'reorder_level': 4, 'price': 149.99, 'description': '4-drawer filing cabinet'},
            {'name': 'Bookshelf', 'category': 'Furniture', 'quantity': 6, 'reorder_level': 3, 'price': 89.99, 'description': '5-tier bookshelf'},
            {'name': 'Desk Lamp', 'category': 'Furniture', 'quantity': 15, 'reorder_level': 10, 'price': 39.99, 'description': 'LED desk lamp'},
            {'name': 'Whiteboard', 'category': 'Furniture', 'quantity': 4, 'reorder_level': 2, 'price': 79.99, 'description': 'Magnetic whiteboard'},
            
            # Software
            {'name': 'Microsoft Office 365', 'category': 'Software', 'quantity': 100, 'reorder_level': 25, 'price': 99.99, 'description': 'Annual subscription'},
            {'name': 'Adobe Creative Suite', 'category': 'Software', 'quantity': 20, 'reorder_level': 10, 'price': 599.99, 'description': 'Creative software bundle'},
            {'name': 'Antivirus Software', 'category': 'Software', 'quantity': 50, 'reorder_level': 20, 'price': 49.99, 'description': 'Enterprise antivirus'},
            {'name': 'Project Management Tool', 'category': 'Software', 'quantity': 30, 'reorder_level': 15, 'price': 29.99, 'description': 'Monthly subscription'},
        ]

        # Create products
        created_products = []
        for product_data in products_data:
            product, created = Product.objects.get_or_create(
                name=product_data['name'],
                defaults=product_data
            )
            if created:
                created_products.append(product)
                self.stdout.write(f'Created product: {product.name}')

        self.stdout.write(f'Created {len(created_products)} products')

        # Create some sample orders
        if created_products:
            # Create a few sample orders
            for i in range(5):
                order = Order.objects.create(
                    created_by=staff_user,
                    notes=f'Sample order {i+1} for testing purposes'
                )
                
                # Add random products to order
                selected_products = random.sample(created_products, random.randint(2, 5))
                total_amount = Decimal('0.00')
                
                for product in selected_products:
                    quantity = random.randint(1, min(5, product.quantity))
                    if quantity > 0:
                        order_item = OrderItem.objects.create(
                            order=order,
                            product=product,
                            quantity=quantity,
                            unit_price=product.price
                        )
                        total_amount += Decimal(str(order_item.subtotal))
                
                order.total_amount = total_amount
                order.save()
                
                # Randomly approve some orders
                if random.choice([True, False]):
                    order.status = 'approved'
                    order.approved_by = admin_user
                    order.save()
                    
                    # Update stock and create transactions
                    for item in order.items.all():
                        if item.product.quantity >= item.quantity:
                            item.product.quantity -= item.quantity
                            item.product.save()
                            
                            StockTransaction.objects.create(
                                product=item.product,
                                transaction_type='out',
                                quantity=item.quantity,
                                reference_order=order,
                                reason=f'Order {order.order_number} approved',
                                created_by=admin_user
                            )
                
                self.stdout.write(f'Created order: {order.order_number}')

        self.stdout.write(
            self.style.SUCCESS('Sample data created successfully!')
        )
        self.stdout.write('Login credentials:')
        self.stdout.write('Staff User - Username: staff, Password: staff123')
        self.stdout.write('Admin User - Username: admin, Password: admin123')