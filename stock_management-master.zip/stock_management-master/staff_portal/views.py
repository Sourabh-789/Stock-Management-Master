"""
Views for Staff Portal Inventory Management System
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Q, Sum, F
from django.utils import timezone
from django.core.paginator import Paginator
from django.core.mail import send_mail
from django.urls import reverse
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime, timedelta
import json
import razorpay

from django.db import transaction, models
from .models import Product, Order, OrderItem, StockTransaction, RestockRequest, Notification
from . import notifications


def is_staff_user(user):
    """Check if user is staff"""
    return user.is_authenticated and user.is_staff


@login_required
@user_passes_test(is_staff_user)
def dashboard(request):
    """Staff dashboard with overview"""
    context = {
        'total_products': Product.objects.count(),
        'low_stock_count': Product.objects.filter(quantity__lte=F('reorder_level')).count(),
        'pending_orders': Order.objects.filter(status='pending').count(),
        'recent_orders': Order.objects.all()[:5],
        'total_inventory_value': Product.objects.aggregate(total_value=Sum(F('quantity') * F('price')))['total_value'] or 0,
        'notifications': Notification.objects.filter(user=request.user, is_read=False)[:10],
    }
    return render(request, 'staff_portal/dashboard.html', context)


@login_required
@user_passes_test(is_staff_user)
def products_list(request):
    """Display list of all products with search and filter"""
    products = Product.objects.all()
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        products = products.filter(name__icontains=search_query)
    
    # Category filter
    category_filter = request.GET.get('category', '')
    if category_filter:
        products = products.filter(category=category_filter)
    
    # Stock status filter
    stock_status_filter = request.GET.get('stock_status', '')
    if stock_status_filter == 'in_stock':
        products = products.filter(quantity__gt=F('reorder_level'))
    elif stock_status_filter == 'low_stock':
        products = products.filter(quantity__lte=F('reorder_level'), quantity__gt=0)
    elif stock_status_filter == 'out_of_stock':
        products = products.filter(quantity=0)

    # Sort functionality
    sort_by = request.GET.get('sort', '')
    if sort_by == 'quantity_asc':
        products = products.order_by('quantity')
    elif sort_by == 'quantity_desc':
        products = products.order_by('-quantity')
    else:
        products = products.order_by('-updated_at')  # Default sort
    
    # Get all categories for filter dropdown
    categories = Product.objects.values_list('category', flat=True).distinct()
    
    # Pagination
    paginator = Paginator(products, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'categories': categories,
        'search_query': search_query,
        'search_query': search_query,
        'category_filter': category_filter,
        'stock_status_filter': stock_status_filter,
        'sort_by': sort_by,
    }
    return render(request, 'staff_portal/products.html', context)


@login_required
@user_passes_test(is_staff_user)
def orders_list(request):
    """Display all orders with filtering"""
    orders = Order.objects.all()
    
    # Status filter
    status_filter = request.GET.get('status', '')
    if status_filter:
        orders = orders.filter(status=status_filter)
    
    # Pagination
    paginator = Paginator(orders, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'status_filter': status_filter,
        'status_choices': Order.STATUS_CHOICES,
    }
    return render(request, 'staff_portal/orders.html', context)


@login_required
@user_passes_test(is_staff_user)
@login_required
@user_passes_test(is_staff_user)
def create_order(request):
    """Create new order with auto-restock request logic"""
    if request.method == 'POST':
        try:
            with transaction.atomic():
                products_data = json.loads(request.POST.get('products', '[]'))
                customer_name = request.POST.get('customer_name')
                customer_contact = request.POST.get('customer_contact')
                customer_email = request.POST.get('customer_email')
                notes = request.POST.get('notes', '')
                
                items_oos = False
                reserved_products = [] # Track items to reserve if order is successful
                
                # Create Order First (Always)
                order = Order.objects.create(
                    created_by=request.user,
                    customer_name=customer_name,
                    customer_contact=customer_contact,
                    customer_email=customer_email,
                    notes=notes
                )
                
                total_amount = 0
                
                for item_data in products_data:
                    product = Product.objects.get(id=item_data['product_id'])
                    quantity = int(item_data['quantity'])
                    
                    # Create Order Item
                    item = OrderItem.objects.create(
                        order=order,
                        product=product,
                        quantity=quantity,
                        unit_price=product.price
                    )
                    
                    # Check for Stockout using Available Quantity
                    if product.available_quantity < quantity:
                        items_oos = True
                        # Create Restock Request linked to this order
                        RestockRequest.objects.create(
                            product=product,
                            requested_quantity=quantity,
                            reason=f"Auto-Request for Order #{order.order_number} (Customer: {customer_name})",
                            requested_by=request.user,
                            status='pending',
                            related_order=order
                        )
                        # Notify Admin
                        Notification.objects.create(
                            user=User.objects.filter(is_superuser=True).first(),
                            message=f"Urgent Restock Needed: {product.name} x {quantity} for Order #{order.order_number}"
                        )
                    else:
                        # Track for reservation
                        reserved_products.append({'product': product, 'quantity': quantity})

                order.calculate_total()
                
                if items_oos:
                    messages.warning(request, f"Order #{order.order_number} created but is PENDING due to insufficient stock. Restock requests sent to Admin.")
                else:
                    # All items available. Reserve Stock and set to Pending Payment
                    for item in reserved_products:
                        prod = item['product']
                        prod.reserved_quantity += item['quantity']
                        prod.save()
                    
                    order.status = 'pending_payment'
                    order.save()
                    
                    # Mock Notification to Customer
                    messages.success(request, f"Order #{order.order_number} placed. Status: Pending Payment. SMS sent to customer.")
                    
                    # Send REAL Notification using Service
                    payment_link = request.build_absolute_uri(
                        reverse('payment_page', args=[order.order_number])
                    )
                    notifications.send_order_notification(order, payment_link)
                
            return redirect('orders_list')
                 
        except Exception as e:
            messages.error(request, f"Error creating order: {str(e)}")
            
    products = Product.objects.filter(quantity__gt=0) # Show products for selection
    # Actually, we should show ALL products so they can request restock for OOS ones
    products = Product.objects.all() 
    
    return render(request, 'staff_portal/create_order.html', {'products': products})


@login_required
@user_passes_test(is_staff_user)
def order_detail(request, order_id):
    """View order details"""
    order = get_object_or_404(Order, id=order_id)
    return render(request, 'staff_portal/order_detail.html', {'order': order})


@login_required
@user_passes_test(is_staff_user)
def approve_order(request, order_id):
    """Approve order and update stock"""
    order = get_object_or_404(Order, id=order_id)
    
    if order.status not in ['pending', 'paid', 'pending_payment']:
        messages.error(request, 'Only pending or paid orders can be approved.')
        return redirect('order_detail', order_id=order_id)
    
    try:
        # Check if sufficient stock is available (if not already reserved)
        if order.status == 'pending':
            for item in order.items.all():
                if item.product.available_quantity < item.quantity:
                    messages.error(request, f'Insufficient stock for {item.product.name}')
                    return redirect('order_detail', order_id=order_id)
        
        # Update stock and create transactions
        for item in order.items.all():
            product = item.product
            
            if order.status == 'pending_payment' or order.status == 'paid':
                 # Stock was reserved, release reservation and deduct actual
                 product.reserved_quantity -= item.quantity
                 product.quantity -= item.quantity
            else:
                 # Legacy flow: just deduct
                 product.quantity -= item.quantity
            
            product.save()
            
            # Create stock transaction
            StockTransaction.objects.create(
                product=product,
                transaction_type='out',
                quantity=item.quantity,
                reference_order=order,
                reason=f'Order {order.order_number} approved',
                created_by=request.user
            )
        
        # Update order status
        current_status = order.status
        order.status = 'confirmed' # Use confirmed for completed workflow
        order.approved_by = request.user
        order.save()
        
        messages.success(request, f'Order {order.order_number} confirmed and stock deducted!')
        
    except Exception as e:
        messages.error(request, f'Error approving order: {str(e)}')
    
    return redirect('order_detail', order_id=order_id)


@login_required
@user_passes_test(is_staff_user)
def reject_order(request, order_id):
    """Reject order with reason"""
    order = get_object_or_404(Order, id=order_id)
    
    if order.status != 'pending':
        messages.error(request, 'Only pending orders can be rejected.')
        return redirect('order_detail', order_id=order_id)
    
    if request.method == 'POST':
        rejection_reason = request.POST.get('rejection_reason', '')
        if not rejection_reason:
            messages.error(request, 'Rejection reason is required.')
            return redirect('order_detail', order_id=order_id)
        
        # Release reserved stock if applicable
        if order.status == 'pending_payment':
            for item in order.items.all():
                item.product.reserved_quantity -= item.quantity
                item.product.save()

        order.status = 'rejected'
        order.rejection_reason = rejection_reason
        order.save()
        
        messages.success(request, f'Order {order.order_number} rejected.')
        return redirect('order_detail', order_id=order_id)
    
    return render(request, 'staff_portal/reject_order.html', {'order': order})


@login_required
@user_passes_test(is_staff_user)
def reports(request):
    """Reports page with order history and stock movements"""
    # Date filtering
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    
    # Order history
    orders = Order.objects.all()
    if start_date:
        orders = orders.filter(created_at__date__gte=start_date)
    if end_date:
        orders = orders.filter(created_at__date__lte=end_date)
    
    # Stock transactions
    transactions = StockTransaction.objects.all()
    if start_date:
        transactions = transactions.filter(created_at__date__gte=start_date)
    if end_date:
        transactions = transactions.filter(created_at__date__lte=end_date)
    
    # Summary statistics
    total_orders = orders.count()
    approved_orders = orders.filter(status='approved').count()
    rejected_orders = orders.filter(status='rejected').count()
    pending_orders = orders.filter(status='pending').count()
    
    context = {
        'orders': orders[:50],  # Limit to recent 50 orders
        'transactions': transactions[:50],  # Limit to recent 50 transactions
        'start_date': start_date,
        'end_date': end_date,
        'total_orders': total_orders,
        'approved_orders': approved_orders,
        'rejected_orders': rejected_orders,
        'pending_orders': pending_orders,
    }
    return render(request, 'staff_portal/reports.html', context)


@login_required
@user_passes_test(is_staff_user)
def alerts(request):
    """Alerts page showing low stock and out of stock products"""
    # Get low stock products (quantity <= reorder_level)
    low_stock_products = Product.objects.filter(
        quantity__lte=F('reorder_level'),
        quantity__gt=0
    )
    
    # Get out of stock products
    out_of_stock_products = Product.objects.filter(quantity=0)
    
    context = {
        'low_stock_products': low_stock_products,
        'out_of_stock_products': out_of_stock_products,
    }
    return render(request, 'staff_portal/alerts.html', context)


# AJAX Views
@login_required
@user_passes_test(is_staff_user)
def get_product_info(request, product_id):
    """Get product information for AJAX requests"""
    try:
        product = Product.objects.get(id=product_id)
        data = {
            'id': product.id,
            'name': product.name,
            'price': float(product.price),
            'quantity': product.quantity,
            'category': product.category,
        }
        return JsonResponse(data)
    except Product.DoesNotExist:
        return JsonResponse({'error': 'Product not found'}, status=404)


@login_required
@user_passes_test(is_staff_user)
def create_restock_request(request, product_id):
    """Create a restock request for a product"""
    product = get_object_or_404(Product, id=product_id)
    
    if request.method == 'POST':
        quantity = int(request.POST.get('quantity', 0))
        reason = request.POST.get('reason', '')
        dealer_name = request.POST.get('dealer_name', '')
        cost_price = request.POST.get('cost_price')
        
        if quantity > 0:
            from .models import RestockRequest  # Import here to avoid circular dependency
            
            # Create request
            RestockRequest.objects.create(
                product=product,
                requested_quantity=quantity,
                reason=reason,
                dealer_name=dealer_name,
                cost_price=cost_price if cost_price else 0,
                requested_by=request.user
            )
            messages.success(request, f'Restock request for {product.name} submitted successfully.')
        else:
            messages.error(request, 'Invalid quantity.')
            
    return redirect('alerts')


@login_required
@user_passes_test(is_staff_user)
@transaction.atomic
def simulate_payment(request, order_id):
    """Simulate payment gateway callback"""
    order = get_object_or_404(Order, id=order_id)
    
    if order.status != 'pending_payment':
        messages.error(request, 'Order is not pending payment.')
        return redirect('order_detail', order_id=order_id)
        
    # 1. Update status to Paid
    order.status = 'paid'
    order.payment_method = 'QR_CODE' # Simulated
    order.save()
    
    # 2. Staff Notification
    Notification.objects.create(
        user=request.user, # Notify current user (or all staff?)
        message=f"Payment received for Order {order.order_number}"
    )
    
    # 3. Auto-Confirm and Deduct Stock (Reuse approve logic or do it here)
    # We will do it here to ensure the flow "Once payment confirmed -> Confirmed -> Deduct"
    try:
        for item in order.items.all():
            product = item.product
            # Stock was reserved. Convert reservation to deduction.
            product.reserved_quantity -= item.quantity
            product.quantity -= item.quantity
            product.save()
            
            StockTransaction.objects.create(
                product=product,
                transaction_type='out',
                quantity=item.quantity,
                reference_order=order,
                reason=f'Order {order.order_number} Payment Confirmed',
                created_by=request.user
            )
            
        order.status = 'confirmed'
        order.save()
        
        messages.success(request, f"Payment Confirmed for Order {order.order_number}. Stock Deducted.")
        
    except Exception as e:
        messages.error(request, f"Error creating transactions: {str(e)}")
        
    return redirect('order_detail', order_id=order_id)


def payment_page(request, order_number):
    """
    Public view for customers to see bill and pay.
    Initializes Razorpay Order.
    """
    try:
        order = Order.objects.get(order_number=order_number)
    except Order.DoesNotExist:
        return render(request, 'staff_portal/payment_error.html', {'message': 'Order not found'})
        
    if order.status != 'pending_payment':
        return render(request, 'staff_portal/payment_error.html', 
                     {'message': f'Order is already {order.get_status_display()}'})
    
    # Initialize Razorpay Client
    client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
    
    # Create Razorpay Order if not exists
    if not order.razorpay_order_id:
        razorpay_order = client.order.create({
            "amount": int(order.total_amount * 100), # Amount in paise
            "currency": "INR",
            "receipt": order.order_number,
            "payment_capture": "1"
        })
        order.razorpay_order_id = razorpay_order['id']
        order.save()
    
    context = {
        'order': order,
        'razorpay_key_id': settings.RAZORPAY_KEY_ID,
        'razorpay_amount': int(order.total_amount * 100),
        'callback_url': request.build_absolute_uri(reverse('payment_callback')),
    }
    return render(request, 'staff_portal/payment_page.html', context)


@csrf_exempt
def payment_callback(request):
    """
    Handle Razorpay Webhook/Callback
    """
    if request.method == "POST":
        try:
            payment_id = request.POST.get('razorpay_payment_id', '')
            razorpay_order_id = request.POST.get('razorpay_order_id', '')
            signature = request.POST.get('razorpay_signature', '')
            
            # Verify Signature
            client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
            params_dict = {
                'razorpay_order_id': razorpay_order_id,
                'razorpay_payment_id': payment_id,
                'razorpay_signature': signature
            }
            client.utility.verify_payment_signature(params_dict)
            
            # Signature Verified - Process Order
            order = Order.objects.get(razorpay_order_id=razorpay_order_id)
            
            if order.status == 'pending_payment':
                with transaction.atomic():
                    order.status = 'paid'
                    order.payment_method = 'Razorpay'
                    order.razorpay_payment_id = payment_id
                    order.save()
                    
                    # Notify Staff
                    Notification.objects.create(
                        user=order.created_by,
                        message=f"Payment received (Razorpay) from customer for Order {order.order_number}. Order has been confirmed."
                    )

                    # Notify Customer with Receipt
                    notifications.send_payment_receipt(order)
                    
                    # Deduct Stock
                    for item in order.items.all():
                        product = item.product
                        product.reserved_quantity -= item.quantity
                        product.quantity -= item.quantity
                        product.save()
                        
                        StockTransaction.objects.create(
                            product=product,
                            transaction_type='out',
                            quantity=item.quantity,
                            reference_order=order,
                            reason=f'Order {order.order_number} Razorpay Payment',
                            created_by=order.created_by # Or system user
                        )
                    
                    order.status = 'confirmed'
                    order.save()
            
            return render(request, 'staff_portal/payment_success.html', {'order': order})
            
        except Exception as e:
            logger = logging.getLogger(__name__)
            logger.error(f"Payment verification failed: {str(e)}")
            return render(request, 'staff_portal/payment_error.html', {'message': 'Payment verification failed'})
            
    return render(request, 'staff_portal/payment_error.html', {'message': 'Invalid Request'})