# Deployment Guide - Smart Inventory Management System

## Pre-Deployment Checklist

### 1. Environment Setup
- [ ] Python 3.8+ installed
- [ ] MySQL Server installed and running
- [ ] Virtual environment created and activated
- [ ] All dependencies installed from requirements.txt

### 2. Database Configuration
- [ ] MySQL database `inventory_db` created
- [ ] Database credentials updated in settings.py
- [ ] Database connection tested

### 3. Django Setup
- [ ] Secret key configured (change from default)
- [ ] DEBUG set to False for production
- [ ] ALLOWED_HOSTS configured
- [ ] Static files configuration verified

## Quick Setup Commands

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Database Setup
```bash
# Create MySQL database
mysql -u root -p
CREATE DATABASE inventory_db;
exit

# Run Django setup
python setup_database.py
```

### 3. Start Development Server
```bash
python manage.py runserver
```

## Production Deployment

### 1. Settings Configuration
Update `inventory_system/settings.py`:

```python
# Security
DEBUG = False
SECRET_KEY = 'your-production-secret-key'
ALLOWED_HOSTS = ['your-domain.com', 'www.your-domain.com']

# Database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'inventory_db',
        'USER': 'production_user',
        'PASSWORD': 'secure_password',
        'HOST': 'localhost',
        'PORT': '3306',
        'OPTIONS': {
            'sql_mode': 'traditional',
        }
    }
}

# Static Files
STATIC_ROOT = '/path/to/static/files/'
```

### 2. Web Server Configuration (Apache/Nginx)

#### Apache Configuration
```apache
<VirtualHost *:80>
    ServerName your-domain.com
    DocumentRoot /path/to/inventory_system
    
    WSGIDaemonProcess inventory_system python-path=/path/to/inventory_system
    WSGIProcessGroup inventory_system
    WSGIScriptAlias / /path/to/inventory_system/inventory_system/wsgi.py
    
    Alias /static /path/to/static/files/
    <Directory /path/to/static/files/>
        Require all granted
    </Directory>
    
    <Directory /path/to/inventory_system/inventory_system>
        <Files wsgi.py>
            Require all granted
        </Files>
    </Directory>
</VirtualHost>
```

#### Nginx Configuration
```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location /static/ {
        alias /path/to/static/files/;
    }
    
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### 3. Production Commands
```bash
# Collect static files
python manage.py collectstatic --noinput

# Create superuser
python manage.py createsuperuser

# Run with Gunicorn
pip install gunicorn
gunicorn inventory_system.wsgi:application --bind 127.0.0.1:8000
```

## Security Considerations

### 1. Database Security
- [ ] Use strong database passwords
- [ ] Limit database user permissions
- [ ] Enable MySQL SSL if needed
- [ ] Regular database backups

### 2. Application Security
- [ ] Change default SECRET_KEY
- [ ] Set DEBUG = False
- [ ] Configure ALLOWED_HOSTS
- [ ] Use HTTPS in production
- [ ] Regular security updates

### 3. User Management
- [ ] Create strong admin passwords
- [ ] Limit staff user permissions
- [ ] Regular password updates
- [ ] Monitor user activity

## Monitoring & Maintenance

### 1. Log Files
- Django logs: Check for application errors
- Web server logs: Monitor access and errors
- Database logs: Monitor performance and errors

### 2. Backup Strategy
```bash
# Database backup
mysqldump -u username -p inventory_db > backup_$(date +%Y%m%d).sql

# Application backup
tar -czf app_backup_$(date +%Y%m%d).tar.gz /path/to/inventory_system
```

### 3. Regular Maintenance
- [ ] Database optimization
- [ ] Log file rotation
- [ ] Security updates
- [ ] Performance monitoring

## Testing Deployment

### 1. Functionality Tests
- [ ] User authentication works
- [ ] All pages load correctly
- [ ] Database operations work
- [ ] Static files serve correctly

### 2. Performance Tests
- [ ] Page load times acceptable
- [ ] Database queries optimized
- [ ] Memory usage within limits

### 3. Security Tests
- [ ] Authentication required for all staff pages
- [ ] CSRF protection working
- [ ] SQL injection prevention
- [ ] XSS protection active

## Troubleshooting

### Common Issues

1. **Static Files Not Loading**
   ```bash
   python manage.py collectstatic
   # Check STATIC_ROOT and STATIC_URL settings
   ```

2. **Database Connection Error**
   ```bash
   # Test database connection
   python manage.py dbshell
   # Check credentials and MySQL service
   ```

3. **Permission Denied**
   ```bash
   # Check file permissions
   chmod -R 755 /path/to/inventory_system
   # Check user permissions in database
   ```

4. **Import Errors**
   ```bash
   # Check Python path
   pip list
   # Reinstall requirements
   pip install -r requirements.txt
   ```

## Support

For deployment issues:
1. Check Django documentation
2. Review error logs
3. Verify configuration settings
4. Test in development environment first

## Post-Deployment

### 1. Initial Setup
- [ ] Create admin user
- [ ] Import initial product data
- [ ] Configure user accounts
- [ ] Test all functionality

### 2. User Training
- [ ] Staff user training
- [ ] Admin user training
- [ ] Documentation provided
- [ ] Support procedures established

### 3. Go-Live
- [ ] Final testing completed
- [ ] Backup procedures in place
- [ ] Monitoring configured
- [ ] Support team ready