#!/usr/bin/env python
"""
Database setup script for the Smart Inventory Management System
"""
import os
import sys
import django
from django.core.management import execute_from_command_line

def setup_database():
    """Setup the database and create initial data"""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'inventory_system.settings')
    django.setup()
    
    print("Setting up Smart Inventory Management System...")
    print("=" * 50)
    
    # Make migrations
    print("1. Creating database migrations...")
    execute_from_command_line(['manage.py', 'makemigrations'])
    
    # Apply migrations
    print("2. Applying database migrations...")
    execute_from_command_line(['manage.py', 'migrate'])
    
    # Create sample data
    print("3. Creating sample data...")
    execute_from_command_line(['manage.py', 'create_sample_data'])
    
    print("=" * 50)
    print("Setup completed successfully!")
    print("\nYou can now run the server with:")
    print("python manage.py runserver")
    print("\nLogin credentials:")
    print("Staff User - Username: staff, Password: staff123")
    print("Admin User - Username: admin, Password: admin123")
    print("\nAccess the application at: http://127.0.0.1:8000/")

if __name__ == '__main__':
    setup_database()