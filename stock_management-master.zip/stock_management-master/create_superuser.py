import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'inventory_system.settings_sqlite')
django.setup()

from django.contrib.auth.models import User

try:
    User.objects.create_superuser('pratik', 'pratik@example.com', '123')
    print("✓ Superuser 'pratik' created successfully!")
except Exception as e:
    print(f"Error: {e}")
