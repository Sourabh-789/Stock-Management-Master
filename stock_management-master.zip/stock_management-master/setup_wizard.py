import os

def main():
    print("=============================================")
    print("   STOCK MANAGEMENT NOTIFICATION SETUP      ")
    print("=============================================")
    print("This wizard will help you set up SMS and Email credentials.")
    print("Please have your Twilio and Gmail details ready.")
    print("Press Enter to skip any setting you don't want to change.\n")

    # 1. Get Inputs
    print("--- SMS Configuration (Twilio) ---")
    sid = input("Enter Twilio Account SID: ").strip()
    token = input("Enter Twilio Auth Token: ").strip()
    phone = input("Enter Twilio Phone Number (e.g. +123...): ").strip()
    
    print("\n--- Email Configuration (Gmail) ---")
    email_user = input("Enter Gmail Address: ").strip()
    email_pass = input("Enter Gmail App Password (16 chars): ").strip()

    # 2. Read existing .env
    env_lines = []
    if os.path.exists('.env'):
        with open('.env', 'r') as f:
            env_lines = f.readlines()
    else:
        print("\nCreating new .env file...")
    
    # 3. Prepare new config map
    new_config = {}
    if sid: new_config['TWILIO_ACCOUNT_SID'] = sid
    if token: new_config['TWILIO_AUTH_TOKEN'] = token
    if phone: new_config['TWILIO_PHONE_NUMBER'] = phone
    if email_user: new_config['EMAIL_HOST_USER'] = email_user
    if email_pass: new_config['EMAIL_HOST_PASSWORD'] = email_pass
    
    # 4. Update lines
    final_lines = []
    processed_keys = set()
    
    for line in env_lines:
        line_stripped = line.strip()
        if not line_stripped or line_stripped.startswith('#'):
            final_lines.append(line)
            continue
            
        key = line.split('=')[0].strip()
        if key in new_config:
            # Replace this line
            final_lines.append(f"{key}={new_config[key]}\n")
            processed_keys.add(key)
        else:
            final_lines.append(line)
            
    # 5. Append missing keys
    if final_lines and not final_lines[-1].endswith('\n'):
        final_lines.append('\n')
        
    for key, val in new_config.items():
        if key not in processed_keys:
            final_lines.append(f"{key}={val}\n")
            
    # 6. Write back
    try:
        with open('.env', 'w') as f:
            f.writelines(final_lines)
        print("\n[SUCCESS] Credentials saved to .env file!")
        print("IMPORTANT: You must RESTART your server for changes to take effect.")
        print("Run: Ctrl+C  then  python manage.py runserver")
    except Exception as e:
        print(f"\n[ERROR] Could not write to .env file: {e}")

if __name__ == "__main__":
    main()
