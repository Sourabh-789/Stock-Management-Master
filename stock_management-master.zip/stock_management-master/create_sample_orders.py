#!/usr/bin/env python
"""
Create sample orders for demonstration
"""
import os
import sys
import django
from decimal import Decimal
import random

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'inventory_system.settings_sqlite')
django.setup()

from django.contrib.auth.models import User
from staff_portal.models import Product, Order, OrderItem, StockTransaction

def create_sample_orders():
    """Create sample orders for demonstration"""
    try:
        # Get users
        staff_user = User.objects.get(username='staff')
        admin_user = User.objects.get(username='admin')
        
        # Get some products
        products = list(Product.objects.all()[:10])
        
        if not products:
            print("No products found. Please run the sample data creation first.")
            return
        
        print(f"Creating sample orders with {len(products)} products...")
        
        # Create 5 sample orders
        for i in range(5):
            order = Order.objects.create(
                created_by=staff_user,
                notes=f'Sample order {i+1} for demonstration purposes'
            )
            
            # Add 2-4 random products to each order
            selected_products = random.sample(products, random.randint(2, 4))
            total_amount = Decimal('0.00')
            
            for product in selected_products:
                quantity = random.randint(1, min(3, max(1, product.quantity)))
                if quantity > 0:
                    order_item = OrderItem.objects.create(
                        order=order,
                        product=product,
                        quantity=quantity,
                        unit_price=product.price
                    )
                    total_amount += Decimal(str(order_item.subtotal))
            
            order.total_amount = total_amount
            order.save()
            
            # Randomly approve some orders
            if i < 2:  # Approve first 2 orders
                order.status = 'approved'
                order.approved_by = admin_user
                order.save()
                
                # Update stock and create transactions
                for item in order.items.all():
                    if item.product.quantity >= item.quantity:
                        item.product.quantity -= item.quantity
                        item.product.save()
                        
                        StockTransaction.objects.create(
                            product=item.product,
                            transaction_type='out',
                            quantity=item.quantity,
                            reference_order=order,
                            reason=f'Order {order.order_number} approved',
                            created_by=admin_user
                        )
            elif i == 4:  # Reject last order
                order.status = 'rejected'
                order.rejection_reason = 'Insufficient budget for this order'
                order.save()
            
            print(f"Created order: {order.order_number} (Status: {order.status})")
        
        print("\n✅ Sample orders created successfully!")
        print("\nOrder Summary:")
        orders = Order.objects.all()
        for order in orders:
            print(f"- {order.order_number}: {order.status.title()} (₹{order.total_amount})")
            
    except Exception as e:
        print(f"Error creating sample orders: {e}")

if __name__ == '__main__':
    create_sample_orders()